<?php
/*
Plugin Name:  Strap Themes Team Members
Plugin URI:   https://strapthemes.com
Description:  Custom post type for Team Members
Version:      1.0.0
Author:       Strap Themes
Author URI:   https://strapthemes.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  st-teams


Strap Themes Team Members is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Strap Themes Team Members is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Strap Themes Team Members. If not, see {URI to Plugin License}.
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {

	die;

}

if ( !function_exists( 'st_teams_install' ) ) {
	function st_teams_install() {
		// trigger our function that registers the custom post type
		st_teams_setup_post_type();
	 
		// clear the permalinks after the post type has been registered
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'st_teams_install' );
}

//Deactivation hook function
if ( !function_exists( 'st_teams_deactivation' ) ) {
	function st_teams_deactivation() {
		// unregister the post type, so the rules are no longer in memory
		unregister_post_type( 'teams' );
		// clear the permalinks to remove our post type's rules from the database
		flush_rewrite_rules();
	}
	register_deactivation_hook( __FILE__, 'st_teams_deactivation' );
}

//Uninstall hook function
/*function st_teams_uninstall() {

}
register_uninstall_hook( __FILE__, 'st_teams_uninstall' );*/

//Activation hook function
if ( !function_exists( 'st_teams_setup_post_type' ) ) {
	function st_teams_setup_post_type() {
		// register the "book" custom post type
		register_post_type( 'teams', 
			array(
				'labels' => array(
					'name'                  => _x( 'Team Members', 'team post type name', 'st_teams' ),
					'singular_name'         => _x( 'Team Member', 'singular team post type name', 'st_teams' ),
					'add_new'               => __( 'Add New', 'st_teams' ),
					'add_new_item'          => __( 'Add New Team Member', 'st_teams' ),
					'edit_item'             => __( 'Edit Team Member', 'st_teams' ),
					'new_item'              => __( 'New Team Member', 'st_teams' ),
					'all_items'             => __( 'All Team Members', 'st_teams' ),
					'view_item'             => __( 'View Team Member', 'st_teams' ),
					'view_items'			=> __( 'View Team Members', 'st_teams' ),
					'search_items'          => __( 'Search Team Members', 'st_teams' ),
					'not_found'             => __( 'No Team Members found', 'st_teams' ),
					'not_found_in_trash'    => __( 'No Team Members found in Trash', 'st_teams' ),
					'parent_item_colon'     => __( 'Parent Team Member', 'st_teams' ),
					'all_items'				=> __( 'All Team Members', 'st_teams' ),
					'archives'				=> __( 'Team Member Archives', 'st_teams' ),
					'attributes'			=> __( 'Team Member Attributes', 'st_teams' ),
					'insert_into_item'		=> __( 'Insert Into Team Member', 'st_teams' ),
					'uploaded_to_this_item'	=> __( 'Uploaded To This Team Member', 'st_teams' ),
					'menu_name'             => _x( 'Team Members', 'team post type menu name', 'st_teams' ),
					'featured_image'        => __( 'Team Members Image', 'st_teams' ),
					'set_featured_image'    => __( 'Set Team Member Image', 'st_teams' ),
					'remove_featured_image' => __( 'Remove Team Member Image', 'st_teams' ),
					'use_featured_image'    => __( 'Use as Team Member Image', 'st_teams' ),
					'filter_items_list'     => __( 'Filter Team Members list', 'st_teams' ),
					'items_list_navigation' => __( 'Team Members list navigation', 'st_teams' ),
					'items_list'            => __( 'Team Members list', 'st_teams' ),
				), 
				'description'   	 => 'Custom post type for Team Members',
				'public'             => true,
				//'publicly_queryable' => true,
				//'show_ui'            => true,
				//'show_in_menu'       => true,
				'menu_position' 	 => 5,
				//'query_var'          => true,
				'rewrite'            => array( 'slug' => 'our-teams' ), // my custom slug,
				//'map_meta_cap'       => true,
				'has_archive'        => true,
				//'hierarchical'       => false,
				'supports'           => array( 
					'title', 
					'editor', 
					'thumbnail', 
					'excerpt', 
					'revisions', 
					'author' 
				),
			)
		);
	}
	add_action( 'init', 'st_teams_setup_post_type' );
}

if ( !function_exists( 'st_teams_team_categories' ) ) {
	function st_teams_team_categories() {
		$labels = [
			'name'              => _x( 'Team Member Categories', 'taxonomy general name' ),
			'singular_name'     => _x( 'Team Member Category', 'taxonomy singular name' ),
			'search_items'      => __( 'Search Team Member Categories' ),
			'all_items'         => __( 'All Team Member Categories' ), 
			'parent_item'       => __( 'Parent Team Member Category' ), 
			'parent_item_colon' => __( 'Parent Team Member Category:' ), 
			'edit_item'         => __( 'Edit Team Member Category' ), 
			'update_item'       => __( 'Update Team Member Category' ), 
			'add_new_item'      => __( 'Add New Team Member Category' ), 
			'new_item_name'     => __( 'New Team Member Category Name' ),
			'menu_name'         => __( 'Categories' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like categories)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'team-category'],
		];
		register_taxonomy('team_category', array('teams'), $args);
	}
	add_action('init', 'st_teams_team_categories');
}

if ( !function_exists( 'st_teams_team_tags' ) ) {
	function st_teams_team_tags()
	{
		$labels = [
			'name'              => _x( 'Team Member Tags', 'taxonomy general name'),
			'singular_name'     => _x( 'Team Member Tag', 'taxonomy singular name'),
			'search_items'      => __( 'Search Team Member Tags' ),
			'all_items'         => __( 'All Team Member Tags' ), 
			'parent_item'       => __( 'Parent Team Member Tag' ), 
			'parent_item_colon' => __( 'Parent Team Member Tag:' ), 
			'edit_item'         => __( 'Edit Team Member Tag' ), 
			'update_item'       => __( 'Update Team Member Tag' ), 
			'add_new_item'      => __( 'Add New Team Member Tag' ), 
			'new_item_name'     => __( 'New Team Member Tag Name' ),
			'menu_name'         => __( 'Tags' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like Tags)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'team-tag'],
		];
		register_taxonomy('team_tag', array('teams'), $args);
	}
	add_action('init', 'st_teams_team_tags');
}