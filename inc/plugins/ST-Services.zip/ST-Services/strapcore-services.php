<?php
/*
Plugin Name:  Strap Themes Services
Plugin URI:   https://strapthemes.com
Description:  Custom post type for Services
Version:      1.0.0
Author:       Strap Themes
Author URI:   https://strapthemes.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  st-services


Strap Themes Services is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Strap Themes Services is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Strap Themes Services. If not, see {URI to Plugin License}.
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {

	die;

}

if ( !function_exists( 'st_services_install' ) ) {
	function st_services_install() {
		// trigger our function that registers the custom post type
		st_services_setup_post_type();
	 
		// clear the permalinks after the post type has been registered
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'st_services_install' );
}

//Deactivation hook function
if ( !function_exists( 'st_services_deactivation' ) ) {
	function st_services_deactivation() {
		// unregister the post type, so the rules are no longer in memory
		unregister_post_type( 'services' );
		// clear the permalinks to remove our post type's rules from the database
		flush_rewrite_rules();
	}
	register_deactivation_hook( __FILE__, 'st_services_deactivation' );
}

//Uninstall hook function
/*function st_services_uninstall() {

}
register_uninstall_hook( __FILE__, 'st_services_uninstall' );*/

//Activation hook function
if ( !function_exists( 'st_services_setup_post_type' ) ) {
	function st_services_setup_post_type() {
		// register the "book" custom post type
		register_post_type( 'services', 
			array(
				'labels' => array(
					'name'                  => _x( 'Services', 'service post type name', 'st_services' ),
					'singular_name'         => _x( 'Service', 'singular service post type name', 'st_services' ),
					'add_new'               => __( 'Add New', 'st_services' ),
					'add_new_item'          => __( 'Add New Service', 'st_services' ),
					'edit_item'             => __( 'Edit Service', 'st_services' ),
					'new_item'              => __( 'New Service', 'st_services' ),
					'all_items'             => __( 'All Services', 'st_services' ),
					'view_item'             => __( 'View Service', 'st_services' ),
					'view_items'			=> __( 'View Services', 'st_services' ),
					'search_items'          => __( 'Search Services', 'st_services' ),
					'not_found'             => __( 'No Services found', 'st_services' ),
					'not_found_in_trash'    => __( 'No Services found in Trash', 'st_services' ),
					'parent_item_colon'     => __( 'Parent Service', 'st_services' ),
					'all_items'				=> __( 'All Services', 'st_services' ),
					'archives'				=> __( 'Service Archives', 'st_services' ),
					'attributes'			=> __( 'Service Attributes', 'st_services' ),
					'insert_into_item'		=> __( 'Insert Into Service', 'st_services' ),
					'uploaded_to_this_item'	=> __( 'Uploaded To This Service', 'st_services' ),
					'menu_name'             => _x( 'Services', 'service post type menu name', 'st_services' ),
					'featured_image'        => __( 'Services Image', 'st_services' ),
					'set_featured_image'    => __( 'Set Service Image', 'st_services' ),
					'remove_featured_image' => __( 'Remove Service Image', 'st_services' ),
					'use_featured_image'    => __( 'Use as Service Image', 'st_services' ),
					'filter_items_list'     => __( 'Filter Services list', 'st_services' ),
					'items_list_navigation' => __( 'Services list navigation', 'st_services' ),
					'items_list'            => __( 'Services list', 'st_services' ),
				), 
				'description'   	 => 'Custom post type for Services',
				'public'             => true,
				//'publicly_queryable' => true,
				//'show_ui'            => true,
				//'show_in_menu'       => true,
				'menu_position' 	 => 5,
				//'query_var'          => true,
				'rewrite'            => array( 'slug' => 'our-services' ), // my custom slug,
				//'map_meta_cap'       => true,
				'has_archive'        => true,
				//'hierarchical'       => false,
				'supports'           => array( 
					'title', 
					'editor', 
					'thumbnail', 
					'excerpt', 
					'revisions', 
					'author' 
				),
			)
		);
	}
	add_action( 'init', 'st_services_setup_post_type' );
}

if ( !function_exists( 'st_services_service_categories' ) ) {
	function st_services_service_categories() {
		$labels = [
			'name'              => _x( 'Service Categories', 'taxonomy general name' ),
			'singular_name'     => _x( 'Service Category', 'taxonomy singular name' ),
			'search_items'      => __( 'Search Service Categories' ),
			'all_items'         => __( 'All Service Categories' ), 
			'parent_item'       => __( 'Parent Service Category' ), 
			'parent_item_colon' => __( 'Parent Service Category:' ), 
			'edit_item'         => __( 'Edit Service Category' ), 
			'update_item'       => __( 'Update Service Category' ), 
			'add_new_item'      => __( 'Add New Service Category' ), 
			'new_item_name'     => __( 'New Service Category Name' ),
			'menu_name'         => __( 'Categories' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like categories)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'service-category'],
		];
		register_taxonomy('service_category', array('services'), $args);
	}
	add_action('init', 'st_services_service_categories');
}

if ( !function_exists( 'st_services_service_tags' ) ) {
	function st_services_service_tags()
	{
		$labels = [
			'name'              => _x( 'Service Tags', 'taxonomy general name'),
			'singular_name'     => _x( 'Service Tag', 'taxonomy singular name'),
			'search_items'      => __( 'Search Service Tags' ),
			'all_items'         => __( 'All Service Tags' ), 
			'parent_item'       => __( 'Parent Service Tag' ), 
			'parent_item_colon' => __( 'Parent Service Tag:' ), 
			'edit_item'         => __( 'Edit Service Tag' ), 
			'update_item'       => __( 'Update Service Tag' ), 
			'add_new_item'      => __( 'Add New Service Tag' ), 
			'new_item_name'     => __( 'New Service Tag Name' ),
			'menu_name'         => __( 'Tags' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like Tags)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'service-tag'],
		];
		register_taxonomy('service_tag', array('services'), $args);
	}
	add_action('init', 'st_services_service_tags');
}