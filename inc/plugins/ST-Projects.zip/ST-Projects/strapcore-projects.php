<?php
/*
Plugin Name:  Strap Themes Projects
Plugin URI:   https://strapthemes.com
Description:  Custom post type for Projects
Version:      1.0.0
Author:       Strap Themes
Author URI:   https://strapthemes.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  st-projects


Strap Themes Projects is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Strap Themes Projects is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Strap Themes Projects. If not, see {URI to Plugin License}.
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {

	die;

}

if ( !function_exists( 'st_projects_install' ) ) {
	function st_projects_install() {
		// trigger our function that registers the custom post type
		st_projects_setup_post_type();
	 
		// clear the permalinks after the post type has been registered
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'st_projects_install' );
}

//Deactivation hook function
if ( !function_exists( 'st_projects_deactivation' ) ) {
	function st_projects_deactivation() {
		// unregister the post type, so the rules are no longer in memory
		unregister_post_type( 'projects' );
		// clear the permalinks to remove our post type's rules from the database
		flush_rewrite_rules();
	}
	register_deactivation_hook( __FILE__, 'st_projects_deactivation' );
}

//Uninstall hook function
/*function st_projects_uninstall() {

}
register_uninstall_hook( __FILE__, 'st_projects_uninstall' );*/

//Activation hook function
if ( !function_exists( 'st_projects_setup_post_type' ) ) {
	function st_projects_setup_post_type() {
		// register the "book" custom post type
		register_post_type( 'projects', 
			array(
				'labels' => array(
					'name'                  => _x( 'Projects', 'project post type name', 'st_projects' ),
					'singular_name'         => _x( 'Project', 'singular project post type name', 'st_projects' ),
					'add_new'               => __( 'Add New', 'st_projects' ),
					'add_new_item'          => __( 'Add New Project', 'st_projects' ),
					'edit_item'             => __( 'Edit Project', 'st_projects' ),
					'new_item'              => __( 'New Project', 'st_projects' ),
					'all_items'             => __( 'All Projects', 'st_projects' ),
					'view_item'             => __( 'View Project', 'st_projects' ),
					'view_items'			=> __( 'View Projects', 'st_projects' ),
					'search_items'          => __( 'Search Projects', 'st_projects' ),
					'not_found'             => __( 'No Projects found', 'st_projects' ),
					'not_found_in_trash'    => __( 'No Projects found in Trash', 'st_projects' ),
					'parent_item_colon'     => __( 'Parent Project', 'st_projects' ),
					'all_items'				=> __( 'All Projects', 'st_projects' ),
					'archives'				=> __( 'Project Archives', 'st_projects' ),
					'attributes'			=> __( 'Project Attributes', 'st_projects' ),
					'insert_into_item'		=> __( 'Insert Into Project', 'st_projects' ),
					'uploaded_to_this_item'	=> __( 'Uploaded To This Project', 'st_projects' ),
					'menu_name'             => _x( 'Projects', 'project post type menu name', 'st_projects' ),
					'featured_image'        => __( 'Projects Image', 'st_projects' ),
					'set_featured_image'    => __( 'Set Project Image', 'st_projects' ),
					'remove_featured_image' => __( 'Remove Project Image', 'st_projects' ),
					'use_featured_image'    => __( 'Use as Project Image', 'st_projects' ),
					'filter_items_list'     => __( 'Filter Projects list', 'st_projects' ),
					'items_list_navigation' => __( 'Projects list navigation', 'st_projects' ),
					'items_list'            => __( 'Projects list', 'st_projects' ),
				), 
				'description'   	 => 'Custom post type for Projects',
				'public'             => true,
				//'publicly_queryable' => true,
				//'show_ui'            => true,
				//'show_in_menu'       => true,
				'menu_position' 	 => 5,
				//'query_var'          => true,
				'rewrite'            => array( 'slug' => 'our-projects' ), // my custom slug,
				//'map_meta_cap'       => true,
				'has_archive'        => true,
				//'hierarchical'       => false,
				'supports'           => array( 
					'title', 
					'editor', 
					'thumbnail', 
					'excerpt', 
					'revisions', 
					'author' 
				),
			)
		);
	}
	add_action( 'init', 'st_projects_setup_post_type' );
}

if ( !function_exists( 'st_projects_project_categories' ) ) {
	function st_projects_project_categories() {
		$labels = [
			'name'              => _x( 'Project Categories', 'taxonomy general name' ),
			'singular_name'     => _x( 'Project Category', 'taxonomy singular name' ),
			'search_items'      => __( 'Search Project Categories' ),
			'all_items'         => __( 'All Project Categories' ), 
			'parent_item'       => __( 'Parent Project Category' ), 
			'parent_item_colon' => __( 'Parent Project Category:' ), 
			'edit_item'         => __( 'Edit Project Category' ), 
			'update_item'       => __( 'Update Project Category' ), 
			'add_new_item'      => __( 'Add New Project Category' ), 
			'new_item_name'     => __( 'New Project Category Name' ),
			'menu_name'         => __( 'Categories' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like categories)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'project-category'],
		];
		register_taxonomy('project_category', array('projects'), $args);
	}
	add_action('init', 'st_projects_project_categories');
}

if ( !function_exists( 'st_projects_project_tags' ) ) {
	function st_projects_project_tags()
	{
		$labels = [
			'name'              => _x( 'Project Tags', 'taxonomy general name'),
			'singular_name'     => _x( 'Project Tag', 'taxonomy singular name'),
			'search_items'      => __( 'Search Project Tags' ),
			'all_items'         => __( 'All Project Tags' ), 
			'parent_item'       => __( 'Parent Project Tag' ), 
			'parent_item_colon' => __( 'Parent Project Tag:' ), 
			'edit_item'         => __( 'Edit Project Tag' ), 
			'update_item'       => __( 'Update Project Tag' ), 
			'add_new_item'      => __( 'Add New Project Tag' ), 
			'new_item_name'     => __( 'New Project Tag Name' ),
			'menu_name'         => __( 'Tags' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like Tags)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'project-tag'],
		];
		register_taxonomy('project_tag', array('projects'), $args);
	}
	add_action('init', 'st_projects_project_tags');
}