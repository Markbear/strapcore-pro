<?php
/*
Plugin Name:  Strap Themes FAQs
Plugin URI:   https://strapthemes.com
Description:  Custom post type for FAQs
Version:      1.0.0
Author:       Strap Themes
Author URI:   https://strapthemes.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  strap-themes-faq


Strap Themes FAQs is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Strap Themes FAQs is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Strap Themes FAQs. If not, see {URI to Plugin License}.
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {

	die;

}

if ( !function_exists( 'st_FAQs_install' ) ) {
	function st_FAQs_install() {
		// trigger our function that registers the custom post type
		st_FAQs_setup_post_type();
	 
		// clear the permalinks after the post type has been registered
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'st_FAQs_install' );
}

//Deactivation hook function
if ( !function_exists( 'st_FAQs_deactivation' ) ) {
	function st_FAQs_deactivation() {
		// unregister the post type, so the rules are no longer in memory
		unregister_post_type( 'FAQs' );
		// clear the permalinks to remove our post type's rules from the database
		flush_rewrite_rules();
	}
	register_deactivation_hook( __FILE__, 'st_FAQs_deactivation' );
}

//Uninstall hook function
/*function st_FAQs_uninstall() {

}
register_uninstall_hook( __FILE__, 'st_FAQs_uninstall' );*/

//Activation hook function
if ( !function_exists( 'st_FAQs_setup_post_type' ) ) {
	function st_FAQs_setup_post_type() {
		// register the "book" custom post type
		register_post_type( 'FAQs', 
			array(
				'labels' => array(
					'name'                  => _x( 'FAQs', 'FAQ post type name', 'st_FAQs' ),
					'singular_name'         => _x( 'FAQ', 'singular FAQ post type name', 'st_FAQs' ),
					'add_new'               => __( 'Add New', 'st_FAQs' ),
					'add_new_item'          => __( 'Add New FAQ', 'st_FAQs' ),
					'edit_item'             => __( 'Edit FAQ', 'st_FAQs' ),
					'new_item'              => __( 'New FAQ', 'st_FAQs' ),
					'all_items'             => __( 'All FAQs', 'st_FAQs' ),
					'view_item'             => __( 'View FAQ', 'st_FAQs' ),
					'view_items'			=> __( 'View FAQs', 'st_FAQs' ),
					'search_items'          => __( 'Search FAQs', 'st_FAQs' ),
					'not_found'             => __( 'No FAQs found', 'st_FAQs' ),
					'not_found_in_trash'    => __( 'No FAQs found in Trash', 'st_FAQs' ),
					'parent_item_colon'     => __( 'Parent FAQ', 'st_FAQs' ),
					'all_items'				=> __( 'All FAQs', 'st_FAQs' ),
					'archives'				=> __( 'FAQ Archives', 'st_FAQs' ),
					'attributes'			=> __( 'FAQ Attributes', 'st_FAQs' ),
					'insert_into_item'		=> __( 'Insert Into FAQ', 'st_FAQs' ),
					'uploaded_to_this_item'	=> __( 'Uploaded To This FAQ', 'st_FAQs' ),
					'menu_name'             => _x( 'FAQs', 'FAQ post type menu name', 'st_FAQs' ),
					'featured_image'        => __( 'FAQs Image', 'st_FAQs' ),
					'set_featured_image'    => __( 'Set FAQ Image', 'st_FAQs' ),
					'remove_featured_image' => __( 'Remove FAQ Image', 'st_FAQs' ),
					'use_featured_image'    => __( 'Use as FAQ Image', 'st_FAQs' ),
					'filter_items_list'     => __( 'Filter FAQs list', 'st_FAQs' ),
					'items_list_navigation' => __( 'FAQs list navigation', 'st_FAQs' ),
					'items_list'            => __( 'FAQs list', 'st_FAQs' ),
				), 
				'description'   	 => 'Custom post type for FAQs',
				'public'             => true,
				//'publicly_queryable' => true,
				//'show_ui'            => true,
				//'show_in_menu'       => true,
				'menu_position' 	 => 5,
				//'query_var'          => true,
				'rewrite'            => array( 'slug' => 'our-FAQs' ), // my custom slug,
				//'map_meta_cap'       => true,
				'has_archive'        => true,
				//'hierarchical'       => false,
				'supports'           => array( 
					'title', 
					'editor', 
					'thumbnail', 
					'excerpt', 
					'revisions', 
					'author' 
				),
			)
		);
	}
	add_action( 'init', 'st_FAQs_setup_post_type' );
}

if ( !function_exists( 'st_FAQs_FAQ_categories' ) ) {
	function st_FAQs_FAQ_categories() {
		$labels = [
			'name'              => _x( 'FAQ Categories', 'taxonomy general name' ),
			'singular_name'     => _x( 'FAQ Category', 'taxonomy singular name' ),
			'search_items'      => __( 'Search FAQ Categories' ),
			'all_items'         => __( 'All FAQ Categories' ), 
			'parent_item'       => __( 'Parent FAQ Category' ), 
			'parent_item_colon' => __( 'Parent FAQ Category:' ), 
			'edit_item'         => __( 'Edit FAQ Category' ), 
			'update_item'       => __( 'Update FAQ Category' ), 
			'add_new_item'      => __( 'Add New FAQ Category' ), 
			'new_item_name'     => __( 'New FAQ Category Name' ),
			'menu_name'         => __( 'Categories' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like categories)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'FAQ-category'],
		];
		register_taxonomy('FAQ_category', array('FAQs'), $args);
	}
	add_action('init', 'st_FAQs_FAQ_categories');
}

if ( !function_exists( 'st_FAQs_FAQ_tags' ) ) {
	function st_FAQs_FAQ_tags()
	{
		$labels = [
			'name'              => _x( 'FAQ Tags', 'taxonomy general name'),
			'singular_name'     => _x( 'FAQ Tag', 'taxonomy singular name'),
			'search_items'      => __( 'Search FAQ Tags' ),
			'all_items'         => __( 'All FAQ Tags' ), 
			'parent_item'       => __( 'Parent FAQ Tag' ), 
			'parent_item_colon' => __( 'Parent FAQ Tag:' ), 
			'edit_item'         => __( 'Edit FAQ Tag' ), 
			'update_item'       => __( 'Update FAQ Tag' ), 
			'add_new_item'      => __( 'Add New FAQ Tag' ), 
			'new_item_name'     => __( 'New FAQ Tag Name' ),
			'menu_name'         => __( 'Tags' ),
		];
		$args = [
			'hierarchical'      => true, // make it hierarchical (like Tags)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => ['slug' => 'FAQ-tag'],
		];
		register_taxonomy('FAQ_tag', array('FAQs'), $args);
	}
	add_action('init', 'st_FAQs_FAQ_tags');
}